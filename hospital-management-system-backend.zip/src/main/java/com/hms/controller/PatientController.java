package com.hms.controller;
import com.hms.model.Patient;
import com.hms.service.PatientService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/patients")
@CrossOrigin(origins = "*")
public class PatientController {
    private final PatientService service;
    public PatientController(PatientService service){ this.service = service; }
    @GetMapping
    public List<Patient> getAll(){ return service.getAll(); }
    @GetMapping("/{id}")
    public ResponseEntity<Patient> getById(@PathVariable Long id){
        return service.getById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping("/register")
    public ResponseEntity<Patient> register(@RequestBody Patient p){
        return ResponseEntity.ok(service.register(p));
    }
}