package com.hms.service;
import com.hms.model.Patient;
import com.hms.repository.PatientRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service
public class PatientService {
    private final PatientRepository repo;
    public PatientService(PatientRepository repo){ this.repo = repo; }
    public List<Patient> getAll(){ return repo.findAll(); }
    public Optional<Patient> getById(Long id){ return repo.findById(id); }
    public Patient register(Patient p){ return repo.save(p); }
}